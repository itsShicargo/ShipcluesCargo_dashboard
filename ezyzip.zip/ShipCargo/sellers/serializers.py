# sellers/serializers

from rest_framework import serializers
from .models import Seller
from rest_framework import serializers
from .models import SellerKYCInfo
from .models import Recharge

from .models import WalletTransaction
class SellerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seller
        fields = '__all__'


        


# sellers/serializers

class SellerKYCInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = SellerKYCInfo
        fields = '__all__'


# serializers.py (inside the sellers app directory)

class SellersSerializer(serializers.ModelSerializer):
    kyc_info = SellerKYCInfoSerializer(required=False)

    class Meta:
        model = Seller
        fields = '__all__'

    def create(self, validated_data):
        kyc_info_data = validated_data.pop('kyc_info', None)
        seller = Seller.objects.create(**validated_data)
        if kyc_info_data:
            SellerKYCInfo.objects.create(seller=seller, **kyc_info_data)
        return seller


class WalletTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = WalletTransaction
        fields = '__all__'


class RechargeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Recharge
        fields = '__all__'  # Include all fields from the Recharge model
