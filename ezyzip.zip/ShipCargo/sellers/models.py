from django.db import models

# Create your models here.
# sellers/models.py

from django.db import models

class Seller(models.Model):
    seller_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=40)
    last_name = models.CharField(max_length=40)
   
    company_name = models.CharField(max_length=40)
    brand_name = models.CharField(max_length=40)
    monthly_order = models.IntegerField(default=0)
    email = models.EmailField(max_length=50, unique=True)
    password = models.CharField(max_length=30)
    mob_no = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=1)

    def __str__(self):
        return self.email  # Display username as the object representation


#for hashing 
# from django.contrib.auth.hashers import make_password

# class Sellers(models.Model):
#     # Other fields...
#     password = models.CharField(max_length=128)  # Store hashed password

#     def save(self, *args, **kwargs):
#         self.password = make_password(self.password)
#         super(Sellers, self).save(*args, **kwargs)




#For KYC of Seller
from django.db import models
from .models import Seller

class SellerKYCInfo(models.Model):
    seller_id = models.OneToOneField(Seller, on_delete=models.CASCADE, related_name='kyc_info')
    gst_number = models.CharField(max_length=100, blank=True, null=True)
    gst_certificate = models.FileField(upload_to='gst_certificates/', blank=True, null=True)
    pan = models.CharField(max_length=20, blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=40, blank=True, null=True)
    pincode = models.IntegerField(blank=True, null=True)
    bank_name = models.CharField(max_length=50, blank=True, null=True)
    account_number = models.BigIntegerField(blank=True, null=True)
    ifsc_code = models.CharField(max_length=20, blank=True, null=True)
    cancelled_cheque = models.ImageField(upload_to='cancelled_cheques/', blank=True, null=True)

    def __str__(self):
        return f"KYC Info for {self.seller_id}"




import uuid

class WalletTransaction(models.Model):
    seller = models.ForeignKey(Seller, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    remarks = models.CharField(max_length=255, blank=True, null=True)
    customer_order_id = models.CharField(max_length=50, blank=True, null=True)
    order_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    transaction_type = models.CharField(max_length=20)
    # walletId= models.AutoField(unique=True)

    def __str__(self):
        return f"WalletTransaction for Seller: {self.seller.email}, Amount: {self.amount}"


#Recharge 
from django.db import models
from sellers.models import Seller
import uuid

class Recharge(models.Model):
    seller = models.ForeignKey(Seller, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=50)
    transaction_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    remarks = models.TextField()
    mode = models.CharField(max_length=10, choices=[('debit', 'Debit'), ('credit', 'Credit')])
    status = models.CharField(max_length=20, choices=[('success', 'Success'), ('try_again', 'Try again')])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Recharge of {self.amount} by {self.seller.created_at}"
