# sellers/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_seller, name='create_seller'),
    path('login/', views.seller_login, name='seller_login'),
    #kyc
    path('create-kyc/', views.create_seller_kyc_info, name='create_seller_kyc_info'),
    path('get-kyc/<int:seller_id>/', views.get_seller_kyc_info, name='get_seller_kyc_info'),
    #wallet
    path('transactions/', views.wallet_transaction_list, name='wallet_transaction_list'),
    path('transactions/pk/', views.wallet_transaction_detail, name='wallet_transaction_detail'),

]

