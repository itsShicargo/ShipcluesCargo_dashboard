from django.shortcuts import render

# Create your views here.
# sellers/views.py

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Seller
from .serializers import SellerSerializer

from .models import Seller, SellerKYCInfo
from .serializers import SellerSerializer, SellerKYCInfoSerializer

from .models import WalletTransaction
from sellers.models import Seller
from .serializers import WalletTransactionSerializer
from django.shortcuts import get_object_or_404


@api_view(['POST'])
def create_seller(request):
    serializer = SellerSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def seller_login(request):
    email = request.data.get('email')
    password = request.data.get('password')
    
    try:
        seller = Seller.objects.get(email=email, password=password)
    except Seller.DoesNotExist:
        return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
    
    serializer = SellerSerializer(seller)
    return Response(serializer.data)



#Seller KYC
# sellers/views
@api_view(['POST'])
def create_seller(request):
    serializer = SellerSerializer(data=request.data)
    if serializer.is_valid():
        seller = serializer.save()
        # Create associated SellerKYCInfo
        SellerKYCInfo.objects.create(seller=seller)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def seller_login(request):
    email = request.data.get('email')
    password = request.data.get('password')
    
    try:
        seller = Seller.objects.get(email=email)
        if seller.check_password(password):  # Ensure password matches
            serializer = SellerSerializer(seller)
            # Retrieve associated SellerKYCInfo
            kyc_info = SellerKYCInfo.objects.get(seller=seller)
            kyc_info_serializer = SellerKYCInfoSerializer(kyc_info)
            return Response({
                "seller_info": serializer.data,
                "kyc_info": kyc_info_serializer.data
            })
        else:
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
    except Seller.DoesNotExist:
        return Response({"error": "Seller not found"}, status=status.HTTP_404_NOT_FOUND)
    except SellerKYCInfo.DoesNotExist:
        return Response({"error": "KYC info not found"}, status=status.HTTP_404_NOT_FOUND)




#for KYC
# sellers/views.py


@api_view(['POST'])
def create_seller_kyc_info(request):
    serializer = SellerKYCInfoSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_seller_kyc_info(request, seller_id):
    try:
        kyc_info = SellerKYCInfo.objects.get(seller_id=seller_id)
        serializer = SellerKYCInfoSerializer(kyc_info)
        return Response(serializer.data)
    except SellerKYCInfo.DoesNotExist:
        return Response({"error": "KYC info not found"}, status=status.HTTP_404_NOT_FOUND)


#for Wallet

from .models import WalletTransaction
from sellers.models import Seller
from .serializers import WalletTransactionSerializer
from django.shortcuts import get_object_or_404

@api_view(['GET', 'POST'])
def wallet_transaction_list(request):
    if request.method == 'GET':
        transactions = WalletTransaction.objects.all()
        serializer = WalletTransactionSerializer(transactions, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = WalletTransactionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
def wallet_transaction_detail(request, pk):
    transaction = get_object_or_404(WalletTransaction, pk=pk)

    if request.method == 'GET':
        serializer = WalletTransactionSerializer(transaction)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = WalletTransactionSerializer(transaction, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        transaction.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


#Recharge

# sellers/views.py





# views.py

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import Seller, Recharge, WalletTransaction

@api_view(['POST'])
def recharge(request):
    seller_id = request.data.get('seller_id')
    amount = request.data.get('amount')
    payment_method = request.data.get('payment_method')
    remarks = request.data.get('remarks')
    mode = request.data.get('mode', 'debit')  # Default mode is 'debit'

    # Retrieve the Seller instance by seller_id
    seller = get_object_or_404(Seller, id=seller_id)

    # Create Recharge instance
    recharge = Recharge.objects.create(
        seller=seller,
        amount=amount,
        payment_method=payment_method,
        remarks=remarks,
        mode=mode,
        status='success'  # Assuming recharge is successful
    )

    # Update WalletTransaction based on recharge mode
    transaction_type = 'debit' if mode == 'debit' else 'credit'
    WalletTransaction.objects.create(
        seller=seller,
        amount=amount,
        remarks=remarks,
        transaction_type=transaction_type
    )

    # Update seller's wallet balance based on recharge mode
    if mode == 'debit':
        # Assuming wallet balance is a field of the Seller model
        seller.wallet.balance -= amount
    elif mode == 'credit':
        seller.wallet.balance += amount

    # Save updated wallet balance
    seller.wallet.save()

    # Response data
    data = {
        "message": "Recharge successfully done",
        "recharge_details": {
            "seller_id": seller_id,
            "amount": amount,
            "payment_method": payment_method,
            "remarks": remarks,
            "mode": mode,
            "status": 'success',  # Assuming recharge is successful
            "created_at": recharge.created_at
        }
    }

    return Response(data, status=status.HTTP_201_CREATED)


# from rest_framework import status
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from django.shortcuts import get_object_or_404
# from .models import Seller, Recharge, WalletTransaction
# from .serializers import RechargeSerializer

# @api_view(['POST'])
# def recharge(request):
#     seller_id = request.data.get('seller_id')
#     amount = request.data.get('amount')
#     payment_method = request.data.get('payment_method')
#     remarks = request.data.get('remarks')
#     mode = request.data.get('mode', 'debit')  # Default mode is 'debit'

#     # Retrieve the Seller instance by seller_id
#     seller = get_object_or_404(Seller, seller_id=seller_id)

#     # Create Recharge instance
#     recharge = Recharge.objects.create(
#         seller=seller,
#         amount=amount,
#         payment_method=payment_method,
#         remarks=remarks,
#         mode=mode,
#         status='success'  # Assuming recharge is successful
#     )

#     # Update WalletTransaction amount based on recharge mode
#     if mode == 'debit':
#         transaction_type = 'debit'
#         new_amount = -amount  # Debit amount is negative
#     elif mode == 'credit':
#         transaction_type = 'credit'
#         new_amount = amount

#     # Create or update WalletTransaction for the seller
#     wallet_transaction, created = WalletTransaction.objects.update_or_create(
#         seller=seller,
#         transaction_type=transaction_type,
#         defaults={
#             'amount': new_amount,
#             'remarks': remarks,
#             'transaction_type': transaction_type
#         }
#     )

#     # Calculate new balance
#     wallet_transaction.amount += new_amount
#     wallet_transaction.save()

#     # Response data
#     data = {
#         "message": "Recharge successfully done",
#         "recharge_details": {
#             "seller_id": seller_id,
#             "amount": amount,
#             "payment_method": payment_method,
#             "remarks": remarks,
#             "mode": mode,
#             "status": 'success',  # Assuming recharge is successful
#             "created_at": recharge.created_at
#         }
#     }

#     return Response(data, status=status.HTTP_201_CREATED)
